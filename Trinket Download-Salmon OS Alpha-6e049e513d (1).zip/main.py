from OS import os
while True:
  os()